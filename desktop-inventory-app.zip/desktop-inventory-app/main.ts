let message: string = "Hello, Typescript!";
console.log(message)