var message = "Hello, Typescript!";
console.log(message);
