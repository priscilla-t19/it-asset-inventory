# Desktop Inventory Management Application

This project is a desktop inventory management application designed for storing, adding, editing, and managing IT assets. It utilizes Electron for building cross-platform desktop applications and React for the user interface.

## Features

- Add new IT assets
- Edit existing IT assets
- Delete IT assets
- View detailed information about each asset
- List all IT assets

## Project Structure

```
desktop-inventory-app
├── src
│   ├── main.ts               # Entry point of the application
│   ├── renderer.ts            # Handles rendering and UI communication
│   ├── components             # Contains React components
│   │   ├── AssetList.tsx      # Displays a list of IT assets
│   │   ├── AssetForm.tsx      # Form for adding/editing assets
│   │   └── AssetDetails.tsx    # Displays detailed asset information
│   ├── models                 # Contains data models
│   │   └── Asset.ts           # Defines the structure of an IT asset
│   ├── services               # Contains service classes
│   │   └── AssetService.ts     # Manages IT assets
│   └── types                  # TypeScript types
│       └── index.ts           # Defines application types
├── package.json               # npm configuration file
├── tsconfig.json              # TypeScript configuration file
└── README.md                  # Project documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd desktop-inventory-app
   ```

3. Install dependencies:
   ```
   npm install
   ```

## Usage

To start the application, run the following command:
```
npm start
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License.