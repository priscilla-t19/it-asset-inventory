import React from 'react';
import { IAsset } from '../types';

interface AssetDetailsProps {
    asset: IAsset | null;
}

const AssetDetails: React.FC<AssetDetailsProps> = (props: AssetDetailsProps) => {
    const { asset } = props;
    if (!asset) {
        return <div>Select an asset to see the details.</div>;
    }

    return (
        <div>
            <h2>Asset Details</h2>
            <p><strong>ID:</strong> {asset.id}</p>
            <p><strong>Name:</strong> {asset.name}</p>
            <p><strong>Type:</strong> {asset.type}</p>
            <p><strong>Description:</strong> {asset.description}</p>
        </div>
    );
};

export default AssetDetails;