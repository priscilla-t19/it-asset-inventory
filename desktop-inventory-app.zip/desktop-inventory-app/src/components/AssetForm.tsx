import React, { useState } from 'react';
import Asset from '../models/Asset';

interface AssetFormProps {
    asset?: Asset;
    onSubmit: (asset: Asset) => void;
}

const AssetForm: React.FC<AssetFormProps> = (props: AssetFormProps) => {
    const { asset, onSubmit } = props;
    const [name, setName] = useState(asset ? asset.name : '');
    const [type, setType] = useState(asset ? asset.type : '');
    const [description, setDescription] = useState(asset ? asset.description : '');

    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();
        const newAsset: Asset = {
            id: asset ? asset.id : Date.now(), // Generate a new ID if adding a new asset
            name,
            type,
            description,
        };
        onSubmit(newAsset);
        resetForm();
    };

    const resetForm = () => {
        setName('');
        setType('');
        setDescription('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Name:</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div>
                <label>Type:</label>
                <input type="text" value={type} onChange={(e) => setType(e.target.value)} required />
            </div>
            <div>
                <label>Description:</label>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} required />
            </div>
            <button type="submit">{asset ? 'Edit Asset' : 'Add Asset'}</button>
        </form>
    );
};

export default AssetForm;