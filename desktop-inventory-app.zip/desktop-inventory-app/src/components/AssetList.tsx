import React from 'react';
import { IAsset } from '../types';
import AssetService from '../services/AssetService';

const AssetList: React.FC = () => {
    const [assets, setAssets] = React.useState<IAsset[]>([]);
    const [selectedAsset, setSelectedAsset] = React.useState<IAsset | null>(null);

    React.useEffect(() => {
        const fetchAssets = async () => {
            const assetService = new AssetService();
            const fetchedAssets = await assetService.getAssets();
            setAssets(fetchedAssets);
        };

        fetchAssets();
    }, []);

    const handleSelectAsset = (asset: IAsset) => {
        setSelectedAsset(asset);
    };

    return (
        <div>
            <h2>Asset List</h2>
            <ul>
                {assets.map(asset => (
                    <li key={asset.id} onClick={() => handleSelectAsset(asset)}>
                        {asset.name} - {asset.type}
                    </li>
                ))}
            </ul>
            {selectedAsset && (
                <div>
                    <h3>Selected Asset</h3>
                    <p>Name: {selectedAsset.name}</p>
                    <p>Type: {selectedAsset.type}</p>
                    <p>Description: {selectedAsset.description}</p>
                </div>
            )}
        </div>
    );
};

export default AssetList;