/**import { IAsset } from '../models/IAsset';

class AssetService {
    private assets: IAsset[] = [];

    addAsset(asset: IAsset): void {
        this.assets.push(asset);
    }

    editAsset(updatedAsset: IAsset): void {
        const index = this.assets.findIndex(asset => asset.id === updatedAsset.id);
        if (index !== -1) {
            this.assets[index] = updatedAsset;
        }
    }

    deleteAsset(assetId: string): void {
        this.assets = this.assets.filter(asset => asset.id !== assetId);
    }

    getAssets(): IAsset[] {
        return this.assets;
    }
}
**/
import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';
import { IAsset } from '../models/IAsset';

export class AssetService {
    private db: Database<sqlite3.Database, sqlite3.Statement> | null = null;

    async init() {
        this.db = await open({
            filename: './assets.db',
            driver: sqlite3.Database
        });

        await this.db.run(`
            CREATE TABLE IF NOT EXISTS assets (
                id TEXT PRIMARY KEY,
                department TEXT,
                user TEXT,
                location TEXT,
                status TEXT,
                item TEXT,
                computerName TEXT,
                ipAddress TEXT,
                macAddress TEXT,
                make TEXT,
                model TEXT,
                screenSize TEXT,
                manSerialNumber TEXT,
                gSerialNumber TEXT,
                operatingSystem TEXT,
                osVersion TEXT,
                osBuild TEXT,
                systemType TEXT,
                storageType TEXT,
                storageSize TEXT,
                memorySize TEXT,
                processor TEXT,
                processorSpeed TEXT,
                officeSuite TEXT,
                comments TEXT,
                recommendations TEXT
            )
        `);
    }

    async addAsset(asset: IAsset): Promise<void> {
        if (!this.db) throw new Error('Database not initialized');
        await this.db.run(
            `INSERT INTO assets (
                id, department, user, location, status, item, computerName, ipAddress, macAddress, make, model, screenSize,
                manSerialNumber, gSerialNumber, operatingSystem, osVersion, osBuild, systemType, storageType, storageSize,
                memorySize, processor, processorSpeed, officeSuite, comments, recommendations
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            asset.id, asset.department, asset.user, asset.location, asset.status, asset.item, asset.computerName, asset.ipAddress,
            asset.macAddress, asset.make, asset.model, asset.screenSize, asset.manSerialNumber, asset.gSerialNumber,
            asset.operatingSystem, asset.osVersion, asset.osBuild, asset.systemType, asset.storageType, asset.storageSize,
            asset.memorySize, asset.processor, asset.processorSpeed, asset.officeSuite, asset.comments, asset.recommendations
        );
    }

    async editAsset(asset: IAsset): Promise<void> {
        if (!this.db) throw new Error('Database not initialized');
        await this.db.run(
            `UPDATE assets SET
                department = ?, user = ?, location = ?, status = ?, item = ?, computerName = ?, ipAddress = ?, macAddress = ?,
                make = ?, model = ?, screenSize = ?, manSerialNumber = ?, gSerialNumber = ?, operatingSystem = ?, osVersion = ?,
                osBuild = ?, systemType = ?, storageType = ?, storageSize = ?, memorySize = ?, processor = ?, processorSpeed = ?,
                officeSuite = ?, comments = ?, recommendations = ?
            WHERE id = ?`,
            asset.department, asset.user, asset.location, asset.status, asset.item, asset.computerName, asset.ipAddress,
            asset.macAddress, asset.make, asset.model, asset.screenSize, asset.manSerialNumber, asset.gSerialNumber,
            asset.operatingSystem, asset.osVersion, asset.osBuild, asset.systemType, asset.storageType, asset.storageSize,
            asset.memorySize, asset.processor, asset.processorSpeed, asset.officeSuite, asset.comments, asset.recommendations,
            asset.id
        );
    }

    async deleteAsset(assetId: string): Promise<void> {
        if (!this.db) throw new Error('Database not initialized');
        await this.db.run(`DELETE FROM assets WHERE id = ?`, assetId);
    }

    async getAssets(): Promise<IAsset[]> {
        if (!this.db) throw new Error('Database not initialized');
        return this.db.all<IAsset[]>(`SELECT * FROM assets`);
    }
}