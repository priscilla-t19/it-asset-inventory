import { ipcRenderer } from 'electron';
import React, { useEffect, useState } from 'react';
import AssetList from './components/AssetList';
import AssetForm from './components/AssetForm';
import AssetDetails from './components/AssetDetails';
import { IAsset } from './types';

const App = () => {
    const [assets, setAssets] = useState<IAsset[]>([]);
    const [selectedAsset, setSelectedAsset] = useState<IAsset | null>(null);

    useEffect(() => {
        ipcRenderer.send('get-assets');
        
        ipcRenderer.on('assets-response', (event, assets: IAsset[]) => {
            setAssets(assets);
        });

        return () => {
            ipcRenderer.removeAllListeners('assets-response');
        };
    }, []);

    const handleAssetSelect = (asset: IAsset) => {
        setSelectedAsset(asset);
    };

    const handleAssetAdd = (asset: IAsset) => {
        setAssets([...assets, asset]);
        setSelectedAsset(null);
    };

    const handleAssetEdit = (updatedAsset: IAsset) => {
        setAssets(assets.map(asset => (asset.id === updatedAsset.id ? updatedAsset : asset)));
        setSelectedAsset(null);
    };

    return (
        <div>
            <h1>IT Asset Inventory</h1>
            <AssetForm onAdd={handleAssetAdd} onEdit={handleAssetEdit} selectedAsset={selectedAsset} />
            <AssetList assets={assets} onSelect={handleAssetSelect} />
            {selectedAsset && <AssetDetails asset={selectedAsset} />}
        </div>
    );
};

export default App;