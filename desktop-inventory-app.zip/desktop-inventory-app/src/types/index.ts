export interface IAsset {
     department: string;
    user: string;
    location: string;
    status: string;
    item: string;
    computerName: string;
    ipAddress: string;
    macAddress: string;
    make: string;
    model: string;
    screenSize: string;
    manSerialNumber: string;
    gSerialNumber: string;
    operatingSystem: string;
    osVersion: string;
    osBuild: string;
    systemType: string;
    storageType: string;
    storageSize: string;
    memorySize: string;
    processor: string;
    processorSpeed: string;
    officeSuite: string;
    comments: string;
    recommendations: string;   
}